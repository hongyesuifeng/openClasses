extends Node

func _ready():
    run_validation()

func fail(message:String) -> void:
    print("VALIDATION_FAILED: %s" % message)
    get_tree().quit()

func succeed(message:String) -> void:
    print("VALIDATION_PASSED: %s" % message)
    get_tree().quit()

func run_validation() -> void:
    var main = get_node_or_null("Main")
    if main == null:
        fail("Main scene root not found")
        return

    var emitter := main.get_node_or_null("SmokeEmitter")
    if emitter == null:
        fail("SmokeEmitter node missing")
        return
    if not (emitter is GPUParticles3D):
        fail("SmokeEmitter is not a GPUParticles3D")
        return

    if emitter.amount != 32:
        fail("SmokeEmitter.amount must be 32")
        return
    if not is_equal_approx(emitter.lifetime, 8.0):
        fail("SmokeEmitter.lifetime must be 8 seconds")
        return
    if emitter.draw_order != GPUParticles3D.DRAW_ORDER_VIEW_DEPTH:
        fail("SmokeEmitter.draw_order should be VIEW_DEPTH")
        return

    if emitter.draw_pass_1 == null or not (emitter.draw_pass_1 is QuadMesh):
        fail("SmokeEmitter.draw_pass_1 must be a QuadMesh")
        return

    var mat = emitter.material_override
    if mat == null or not (mat is StandardMaterial3D):
        fail("SmokeEmitter needs a StandardMaterial3D override")
        return
    if mat.albedo_texture == null:
        fail("Smoke material must reference the smoke sprite texture")
        return
    if mat.albedo_texture.resource_path != "res://assets/sprites/particle_sprite_smoke.webp":
        fail("Smoke material should use particle_sprite_smoke.webp")
        return
    if mat.billboard_mode != BaseMaterial3D.BILLBOARD_PARTICLES:
        fail("Smoke material billboard mode must be PARTICLES")
        return
    if not mat.billboard_keep_scale:
        fail("Smoke material should keep scale while billboarding")
        return
    if mat.particles_anim_h_frames != 8 or mat.particles_anim_v_frames != 8:
        fail("Smoke material must be set to an 8x8 flipbook")
        return
    if mat.particles_anim_loop:
        fail("Smoke sprite animation should not loop")
        return

    var process = emitter.process_material
    if process == null or not (process is ParticleProcessMaterial):
        fail("SmokeEmitter needs a ParticleProcessMaterial")
        return
    if process.emission_shape != ParticleProcessMaterial.EMISSION_SHAPE_SPHERE:
        fail("Process material emission shape must be SPHERE")
        return
    if not is_equal_approx(process.emission_sphere_radius, 1.0):
        fail("Emission sphere radius must be 1 meter")
        return
    if process.direction != Vector3(0, 1, 0):
        fail("Base direction should point up (0,1,0)")
        return
    if process.gravity != Vector3(0, 3, 0):
        fail("Gravity should accelerate upward plume (0,3,0)")
        return
    if process.lifetime_randomness < 0.49:
        fail("Enable lifetime randomness around 0.5")
        return
    if process.angle_min > -179 or process.angle_max < 179:
        fail("Angle spread must cover full 360 degrees")
        return
    if process.angular_velocity_min > -9.5 or process.angular_velocity_max < 9.5:
        fail("Angular velocity range should swing at least +/-10")
        return
    if not (is_equal_approx(process.damping_min, 0.3) and is_equal_approx(process.damping_max, 0.3)):
        fail("Damping must lock to 0.3 for both min and max")
        return
    if process.scale_curve == null:
        fail("Scale curve is missing")
        return
    if process.color_ramp == null:
        fail("Smoke color ramp must fade out alpha")
        return
    if process.anim_speed_min > 0.6 or process.anim_speed_max < 0.9:
        fail("Animation speed must lerp roughly between 0.5 and 1.0")
        return
    if not process.turbulence_enabled:
        fail("Turbulence must be enabled for the smoke plume")
        return
    if process.turbulence_influence_min < 0.015 or process.turbulence_influence_max < 0.015:
        fail("Set turbulence influence around 0.02")
        return

    succeed("Smoke emitter configured with plume settings")
