extends Node

const REQUIRED_ANIMATIONS := {
	"idle": "IdleLowered",
	"aim": "IdleRaised",
	"idle_fire": "FiringLowered1",
	"aim_fire": "FiringRaised1",
	"reload": "Reloading",
}

func _ready() -> void:
	var main_scene = load("res://scenes/main.tscn")
	var scene_state = main_scene.get_state()
	var main = main_scene.instantiate()
	add_child(main)
	var player = main.get_node_or_null("PlayerBody")
	if not player or not (player is CharacterBody3D):
		return _fail("PlayerBody node is missing")
	var camera: Node3D = player.get_node_or_null("Camera3D")
	if not camera:
		return _fail("Camera3D node not found under PlayerBody")
	var arms_container: Node3D = player.get_node_or_null("ArmsContainer")
	if not arms_container:
		return _fail("ArmsContainer node missing")
	if arms_container.transform.origin.distance_to(Vector3(0, 0.5, 0)) > 0.001:
		return _fail("ArmsContainer must be positioned at (0, 0.5, 0)")
	var arms_mesh: Node = arms_container.get_node_or_null("ArmsMesh")
	if not arms_mesh:
		return _fail("Instanced ArmsMesh not found under ArmsContainer")
	if arms_mesh.get_scene_file_path() != "res://ScenePrefabs/ArmsPrefab.tscn":
		return _fail("ArmsMesh must instance ScenePrefabs/ArmsPrefab.tscn")

	if not _expect_scene_node_path(scene_state, "PlayerBody", "animation_tree", "ArmsContainer/ArmsMesh/AnimationTree"):
		return
	if not _expect_scene_node_path(scene_state, "PlayerBody", "camera_node", "Camera3D"):
		return
	if not _expect_scene_node_path(scene_state, "PlayerBody", "arms_node", "ArmsContainer"):
		return
	if _get_scene_property(scene_state, "PlayerBody", "hand_state_machine_playback_path") != "parameters/playback":
		return _fail("Hand state machine path must remain 'parameters/playback'")
	if not _check_animation_names(scene_state):
		return
	if not _check_numeric_settings(scene_state):
		return

	print("VALIDATION_PASSED: Arms prefab wiring and exports are configured")
	get_tree().quit(0)



func _check_animation_names(scene_state) -> bool:
	var expectations := {
		"idle_animation_name": REQUIRED_ANIMATIONS["idle"],
		"aiming_animation_name": REQUIRED_ANIMATIONS["aim"],
		"idle_fire_animation_name": REQUIRED_ANIMATIONS["idle_fire"],
		"aiming_fire_animation_name": REQUIRED_ANIMATIONS["aim_fire"],
		"reload_animation_name": REQUIRED_ANIMATIONS["reload"],
	}
	for prop in expectations.keys():
		if _get_scene_property(scene_state, "PlayerBody", prop) != expectations[prop]:
			_fail("%s must be %s" % [prop, expectations[prop]])
			return false
	return true

func _check_numeric_settings(scene_state) -> bool:
	var expected: Array = [
		["rotation_speed", 0.3],
		["camera_actual_rotation_speed", 20.0],
		["arms_actual_rotation_speed", 12.0],
		["vertical_rotation_limit", 80.0],
		["speed", 5.0],
		["jump_velocity", 4.5],
	]
	for pair in expected:
		var prop = pair[0]
		var value = pair[1]
		if not is_equal_approx(_get_scene_property(scene_state, "PlayerBody", prop), value):
			_fail("%s must be %.2f" % [prop, value])
			return false
	return true

func _fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)

func _expect_scene_node_path(state, node_name: String, property_name: String, expected: String) -> bool:
	var value = _get_scene_property(state, node_name, property_name)
	if value != NodePath(expected):
		_fail("%s must reference %s" % [property_name, expected])
		return false
	return true

func _get_scene_property(state, node_name: String, property_name: String):
	for node_idx in state.get_node_count():
		if state.get_node_name(node_idx) == node_name:
			for prop_idx in state.get_node_property_count(node_idx):
				if state.get_node_property_name(node_idx, prop_idx) == property_name:
					return state.get_node_property_value(node_idx, prop_idx)
	return null
