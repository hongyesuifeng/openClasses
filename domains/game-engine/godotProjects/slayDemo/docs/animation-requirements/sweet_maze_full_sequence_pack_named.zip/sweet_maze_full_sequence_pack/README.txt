sweet_maze_full_sequence_pack

This package contains 29 sprite-sequence groups sliced from AI-generated sprite sheets.

Contents:
- assets/enemies/... idle & hit sequences
- assets/player/sprites/... idle & hit
- assets/vfx/... effect sequences
- assets/ui/... animated UI icons
- source_sheets/... original generated atlas sheets used for slicing
- manifest.json ... global sequence list
- per-sequence meta.json ... local playback metadata

Notes:
- Frames were sliced automatically from generated sheets and resized to the requested per-frame sizes.
- Backgrounds were automatically keyed out from the checkerboard-style atlas backgrounds.
- This is a usable first-pass package for Godot integration and validation. Some sequences may still need art cleanup or hand-tuning.

Naming updated to follow the requested convention, e.g. enemy_slime_idle_000.png, enemy_slime_hit_000.png.
