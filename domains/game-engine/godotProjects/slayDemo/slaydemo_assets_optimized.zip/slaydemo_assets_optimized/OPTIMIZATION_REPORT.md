# SlayDemo 美术资源优化报告

本包基于上传的 `slaydemo_assets_optimize.zip` 处理。

## 已执行优化

| 文件 | 原始 | 优化后 | 操作 |
|---|---:|---:|---|
| `intents/intent_sword.png` | 32x32 RGBA | 48x48 RGBA | resize |
| `intents/intent_shield.png` | 32x32 RGBA | 48x48 RGBA | resize |
| `intents/intent_buff.png` | 32x32 RGBA | 48x48 RGBA | resize |
| `intents/intent_debuff.png` | 32x32 RGBA | 48x48 RGBA | resize |
| `intents/intent_stun.png` | 32x32 RGBA | 48x48 RGBA | resize |
| `intents/intent_question.png` | 32x32 RGBA | 48x48 RGBA | resize |
| `status/status_strength.png` | 32x32 RGBA | 40x40 RGBA | resize |
| `status/status_dexterity.png` | 32x32 RGBA | 40x40 RGBA | resize |
| `status/status_vulnerable.png` | 32x32 RGBA | 40x40 RGBA | resize |
| `status/status_weak.png` | 32x32 RGBA | 40x40 RGBA | resize |
| `status/status_poison.png` | 32x32 RGBA | 40x40 RGBA | resize |
| `status/status_thorns.png` | 32x32 RGBA | 40x40 RGBA | resize |
| `status/status_regeneration.png` | 32x32 RGBA | 40x40 RGBA | resize |
| `status/status_fortify.png` | 32x32 RGBA | 40x40 RGBA | resize |
| `templates/card_template_common.png` | 180x250 RGB | 180x250 RGBA | convert_rgba |
| `templates/card_template_uncommon.png` | 180x250 RGB | 180x250 RGBA | convert_rgba |
| `templates/card_template_rare.png` | 180x250 RGB | 180x250 RGBA | convert_rgba |
| `templates/card_template_legendary.png` | 180x250 RGB | 180x250 RGBA | convert_rgba |
| `templates/card_back.png` | 180x250 RGB | 180x250 RGBA | convert_rgba |
| `player_portrait.png` | 64x64 RGBA | 96x96 RGBA | resize |
| `icon_draw_pile.png` | 32x32 RGBA | 40x40 RGBA | resize |
| `icon_discard_pile.png` | 32x32 RGBA | 40x40 RGBA | resize |
| `bars/ui_hp_bar_bg.png` | 256x24 RGB | 512x48 RGBA | resize |
| `bars/ui_hp_bar_fill.png` | 256x24 RGB | 512x48 RGBA | resize |
| `bars/ui_block_bar_fill.png` | 256x24 RGB | 512x48 RGBA | resize |
| `buttons/ui_btn_normal.png` | 192x64 P | 192x64 RGBA | convert_rgba |
| `buttons/ui_btn_hover.png` | 192x64 P | 192x64 RGBA | convert_rgba |
| `buttons/ui_btn_pressed.png` | 192x64 P | 192x64 RGBA | convert_rgba |
| `buttons/ui_btn_disabled.png` | 192x64 P | 192x64 RGBA | convert_rgba |
| `panels/ui_panel_dark.png` | 64x64 P | 64x64 RGBA | convert_rgba |
| `panels/ui_panel_light.png` | 64x64 P | 64x64 RGBA | convert_rgba |
| `templates/cost_crystal.png` | 32x32 RGBA | 40x40 RGBA | resize |

## 优化后 PNG 清单

| 文件 | 尺寸 | 模式 | SHA256前12位 |
|---|---:|---:|---:|
| `bars/ui_block_bar_fill.png` | 512x48 | RGBA | `fdca17458c70` |
| `bars/ui_hp_bar_bg.png` | 512x48 | RGBA | `9aca3b0cfeb3` |
| `bars/ui_hp_bar_fill.png` | 512x48 | RGBA | `1a1548f471e7` |
| `buttons/ui_btn_disabled.png` | 192x64 | RGBA | `f62177f835f3` |
| `buttons/ui_btn_hover.png` | 192x64 | RGBA | `661b0f5a94aa` |
| `buttons/ui_btn_normal.png` | 192x64 | RGBA | `0b46077b5440` |
| `buttons/ui_btn_pressed.png` | 192x64 | RGBA | `0610e42d0a3b` |
| `icon_discard_pile.png` | 40x40 | RGBA | `098bbbb09ada` |
| `icon_draw_pile.png` | 40x40 | RGBA | `d0bffb8969b6` |
| `intents/intent_buff.png` | 48x48 | RGBA | `676d94455f4a` |
| `intents/intent_debuff.png` | 48x48 | RGBA | `779e2dcafeec` |
| `intents/intent_question.png` | 48x48 | RGBA | `0164021e5984` |
| `intents/intent_shield.png` | 48x48 | RGBA | `127df1fc150e` |
| `intents/intent_stun.png` | 48x48 | RGBA | `c97b68f7a89a` |
| `intents/intent_sword.png` | 48x48 | RGBA | `5cdce9f0b151` |
| `panels/ui_panel_dark.png` | 64x64 | RGBA | `a795c20108a9` |
| `panels/ui_panel_light.png` | 64x64 | RGBA | `e8fca04b0ef6` |
| `player_portrait.png` | 96x96 | RGBA | `e5bea3fab5b2` |
| `status/status_dexterity.png` | 40x40 | RGBA | `dabd990850be` |
| `status/status_fortify.png` | 40x40 | RGBA | `69e6d75d7955` |
| `status/status_poison.png` | 40x40 | RGBA | `a8820ac1ac97` |
| `status/status_regeneration.png` | 40x40 | RGBA | `808ec54f07ae` |
| `status/status_strength.png` | 40x40 | RGBA | `027f079ef652` |
| `status/status_thorns.png` | 40x40 | RGBA | `0494b10e53d9` |
| `status/status_vulnerable.png` | 40x40 | RGBA | `af40cf49f42d` |
| `status/status_weak.png` | 40x40 | RGBA | `057532347e0c` |
| `templates/card_back.png` | 180x250 | RGBA | `7fb78a73c3f7` |
| `templates/card_template_common.png` | 180x250 | RGBA | `3dc3b9c05b69` |
| `templates/card_template_legendary.png` | 180x250 | RGBA | `139521ce0421` |
| `templates/card_template_rare.png` | 180x250 | RGBA | `36bcd04e0bae` |
| `templates/card_template_uncommon.png` | 180x250 | RGBA | `56fad531d4f0` |
| `templates/cost_crystal.png` | 40x40 | RGBA | `27750f50e155` |